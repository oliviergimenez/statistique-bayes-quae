library(shiny)
library(bslib)
library(dplyr)
library(tidyr)
library(ggplot2)
library(brms)

# ----------------------------
# Simulate data
# ----------------------------
simulate_data <- function(
    seed = 666,
    n_transects = 10,
    points_per_transect = 10,
    sparse_ids = c(4, 5, 8),
    sparse_points = c(3, 2, 3),
    beta0 = 0,
    beta1 = 0.2,
    sd_transect = 0.3
) {
  set.seed(seed)
  
  npts <- rep(points_per_transect, n_transects)
  if (length(sparse_ids) > 0) {
    npts[sparse_ids] <- sparse_points[seq_along(sparse_ids)]
  }
  
  df <- purrr::map_dfr(seq_len(n_transects), function(tr) {
    b0 <- rnorm(1, 0, sd_transect)
    
    temp0 <- runif(1, 18, 22)
    slope <- runif(1, -0.2, 0.2)
    Temperature <- temp0 + slope * seq_len(npts[tr])
    
    eta <- (beta0 + b0) + beta1 * Temperature
    Ragondins <- rpois(npts[tr], lambda = exp(eta))
    
    tibble(
      Transect = factor(tr),
      Temperature = Temperature,
      Ragondins = Ragondins
    )
  })
  
  df %>%
    mutate(
      Temp = as.numeric(scale(Temperature))
    )
}

# ----------------------------
# Priors helper 
# ----------------------------
make_priors <- function(prior_sd_beta) {
  sd_txt <- format(prior_sd_beta, scientific = FALSE, trim = TRUE)
  
  pri_common <- c(
    set_prior(sprintf("normal(0,%s)", sd_txt), class = "Intercept"),
    set_prior(sprintf("normal(0,%s)", sd_txt), class = "b")
  )
  
  pri_glmm <- c(
    pri_common,
    set_prior("exponential(1)", class = "sd")
  )
  
  list(common = pri_common, glmm = pri_glmm)
}

# ----------------------------
# Fit models
# ----------------------------
fit_three_models <- function(df, prior_sd_beta = 1.5, chains = 2, iter = 2000, warmup = 1000, seed = 666) {
  
  pri <- make_priors(prior_sd_beta)
  
  fit_complete <- brm(
    Ragondins ~ Temp,
    data = df,
    family = poisson("log"),
    prior = pri$common,
    chains = chains, iter = iter, warmup = warmup,
    seed = seed, refresh = 0
  )
  
  fit_nopool <- brm(
    Ragondins ~ Temp + Transect,
    data = df,
    family = poisson("log"),
    prior = pri$common,
    chains = chains, iter = iter, warmup = warmup,
    seed = seed + 1, refresh = 0
  )
  
  fit_partial <- brm(
    Ragondins ~ Temp + (1 | Transect),
    data = df,
    family = poisson("log"),
    prior = pri$glmm,
    chains = chains, iter = iter, warmup = warmup,
    seed = seed + 2, refresh = 0
  )
  
  list(complete = fit_complete, nopool = fit_nopool, partial = fit_partial)
}

predict_grid <- function(df, n_grid = 60) {
  rng <- range(df$Temp, na.rm = TRUE)
  expand_grid(
    Transect = levels(df$Transect),
    Temp = seq(rng[1], rng[2], length.out = n_grid)
  )
}

# ----------------------------
# UI
# ----------------------------
ui <- fluidPage(
  theme = bs_theme(version = 5, bootswatch = "flatly"),
  titlePanel("Chapitre 6 : modèle linéaire généralisé mixte"),
  
  sidebarLayout(
    sidebarPanel(
      h4("Simulation"),
      numericInput("seed", "Seed", 666, min = 1),
      sliderInput("n_tr", "Nombre de transects", min = 4, max = 20, value = 10),
      sliderInput("npts", "Points / transect (sauf rares)", min = 3, max = 20, value = 10),
      checkboxInput("sparse", "Transects rares (4,5,8)", TRUE),
      
      hr(),
      h4("Paramètres vrais"),
      sliderInput("beta0", "beta0 (log)", min = -1, max = 1, value = 0, step = 0.1),
      sliderInput("beta1", "beta1 (log)", min = -0.2, max = 0.6, value = 0.2, step = 0.05),
      sliderInput("sd_transect", "sd transect (intercept)", min = 0, max = 1, value = 0.3, step = 0.05),
      
      hr(),
      h4("Ajustement brms"),
      sliderInput("prior_sd_beta", "Prior SD beta (Normal(0, SD))", min = 0.5, max = 3, value = 1.5, step = 0.1),
      sliderInput("iter", "Iter", min = 1000, max = 4000, value = 2000, step = 500),
      sliderInput("warmup", "Warmup", min = 500, max = 2000, value = 1000, step = 250),
      sliderInput("chains", "Chains", min = 1, max = 4, value = 2, step = 1),
      
      hr(),
      actionButton("simulate", "Simuler", class = "btn-primary"),
      actionButton("fit", "Ajuster (3 modèles)", class = "btn-success")
    ),
    
    mainPanel(
      plotOutput("plot_pooling", height = 520),
      hr(),
      h4("Résumé"),
      verbatimTextOutput("mini_summary")
    )
  )
)

# ----------------------------
# Server
# ----------------------------
server <- function(input, output, session) {
  
  rv <- reactiveValues(df = NULL, fits = NULL)
  
  observeEvent(input$simulate, {
    sparse_ids <- if (isTRUE(input$sparse)) c(4, 5, 8) else integer(0)
    sparse_points <- c(3, 2, 3)
    
    rv$df <- simulate_data(
      seed = input$seed,
      n_transects = input$n_tr,
      points_per_transect = input$npts,
      sparse_ids = sparse_ids,
      sparse_points = sparse_points,
      beta0 = input$beta0,
      beta1 = input$beta1,
      sd_transect = input$sd_transect
    )
    rv$fits <- NULL
  })
  
  observeEvent(input$fit, {
    req(rv$df)
    rv$fits <- fit_three_models(
      rv$df,
      prior_sd_beta = input$prior_sd_beta,
      chains = input$chains,
      iter = input$iter,
      warmup = input$warmup,
      seed = input$seed
    )
  })
  
  output$plot_pooling <- renderPlot({
    req(rv$df)
    df <- rv$df
    
    if (is.null(rv$fits)) {
      return(
        ggplot(df, aes(Temp, Ragondins)) +
          geom_point(alpha = 0.7) +
          facet_wrap(~Transect, ncol = 5, scales = "free_y") +
          labs(x = "Temp (centrée-réduite)", y = "Ragondins") +
          theme_minimal(base_size = 13)
      )
    }
    
    grid <- predict_grid(df, n_grid = 60)
    
    p1 <- fitted(rv$fits$complete, newdata = grid, summary = TRUE)[, "Estimate"]
    p2 <- fitted(rv$fits$nopool,   newdata = grid, summary = TRUE)[, "Estimate"]
    p3 <- fitted(rv$fits$partial,  newdata = grid, summary = TRUE)[, "Estimate"]
    
    pred <- bind_rows(
      mutate(grid, pred = p1, Model = "Complete"),
      mutate(grid, pred = p2, Model = "No pooling"),
      mutate(grid, pred = p3, Model = "Partial (GLMM)")
    )
    
    ggplot(df, aes(Temp, Ragondins)) +
      geom_point(alpha = 0.6) +
      geom_line(data = pred, aes(y = pred, color = Model), linewidth = 0.9) +
      facet_wrap(~Transect, ncol = 5, scales = "free_y") +
      labs(x = "Temp (centrée-réduite)", y = "Ragondins", color = "") +
      theme_minimal(base_size = 13) +
      theme(legend.position = "bottom")
  })
  
  output$mini_summary <- renderText({
    if (is.null(rv$fits)) return("Cliquer sur « Simuler », puis « Ajuster (3 modèles) ».")
    
    fC <- fixef(rv$fits$complete)[, "Estimate"]
    fN <- fixef(rv$fits$nopool)[, "Estimate"]
    fP <- fixef(rv$fits$partial)[, "Estimate"]
    
    # sd random intercept (partial)
    vc <- VarCorr(rv$fits$partial)
    sdP <- as.numeric(vc$Transect$sd[1])
    
    paste0(
      "Complete pooling:  Intercept=", round(fC["Intercept"], 2),
      " | Temp=", round(fC["Temp"], 2), "\n",
      "No pooling:        Intercept=", round(fN["Intercept"], 2),
      " | Temp=", round(fN["Temp"], 2), "\n",
      "Partial (GLMM):    Intercept=", round(fP["Intercept"], 2),
      " | Temp=", round(fP["Temp"], 2),
      " | sd(transect)≈", round(sdP, 2), "\n\n",
      "Vraies valeurs (log): beta0=", input$beta0,
      ", beta1=", input$beta1,
      ", sd_transect=", input$sd_transect, "."
    )
  })
}

shinyApp(ui, server)
