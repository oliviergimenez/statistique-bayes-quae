library(shiny)
library(ggplot2)
library(dplyr)

# Interface utilisateur
ui <- fluidPage(
  titlePanel("Chapitre 1 : le modèle bêta-binomial"),
  
  sidebarLayout(
    sidebarPanel(
      h4("Données observées"),
      sliderInput("n", 
                  "Nombre d'individus suivis (n):", 
                  min = 10, max = 200, value = 57, step = 1),
      sliderInput("y", 
                  "Nombre de survivants (y):", 
                  min = 0, max = 200, value = 19, step = 1),
      
      hr(),
      
      h4("Distribution a priori : Beta(a, b)"),
      sliderInput("a", 
                  "Paramètre a:", 
                  min = 0.1, max = 20, value = 1, step = 0.1),
      sliderInput("b", 
                  "Paramètre b:", 
                  min = 0.1, max = 20, value = 1, step = 0.1),
      
      hr(),
      
      h4("Résultats"),
      htmlOutput("resultats")
    ),
    
    mainPanel(
      plotOutput("plot_distributions", height = "600px")
    )
  )
)

# Serveur
server <- function(input, output, session) {
  
  # Réactivité pour s'assurer que y <= n
  observe({
    updateSliderInput(session, "y", max = input$n)
    if (input$y > input$n) {
      updateSliderInput(session, "y", value = input$n)
    }
  })
  
  # Calculs réactifs
  calculs <- reactive({
    n <- input$n
    y <- input$y
    a <- input$a
    b <- input$b
    
    # Paramètres a posteriori
    a_post <- a + y
    b_post <- b + n - y
    
    # Estimations
    mle <- y / n
    mean_prior <- a / (a + b)
    mean_post <- a_post / (a_post + b_post)
    mode_post <- (a_post - 1) / (a_post + b_post - 2)
    
    # Intervalles de crédibilité
    ic_95 <- qbeta(c(0.025, 0.975), a_post, b_post)
    
    list(
      a_post = a_post,
      b_post = b_post,
      mle = mle,
      mean_prior = mean_prior,
      mean_post = mean_post,
      mode_post = mode_post,
      ic_95 = ic_95
    )
  })
  
  # Affichage des résultats
  output$resultats <- renderUI({
    calc <- calculs()
    
    HTML(paste0(
      "<b>Maximum de vraisemblance :</b> ", round(calc$mle, 3), "<br>",
      "<b>Moyenne a priori :</b> ", round(calc$mean_prior, 3), "<br>",
      "<b>Moyenne a posteriori :</b> ", round(calc$mean_post, 3), "<br>",
      "<b>Mode a posteriori :</b> ", round(calc$mode_post, 3), "<br>",
      "<b>IC 95% a posteriori :</b> [", round(calc$ic_95[1], 3), ", ", 
      round(calc$ic_95[2], 3), "]<br>",
      "<b>Distribution a posteriori :</b> Beta(", round(calc$a_post, 1), ", ", 
      round(calc$b_post, 1), ")"
    ))
  })
  
  # Graphique des distributions
  output$plot_distributions <- renderPlot({
    calc <- calculs()
    theta <- seq(0, 1, length.out = 1000)
    
    df <- data.frame(
      theta = theta,
      Prior = dbeta(theta, input$a, input$b),
      Posteriori = dbeta(theta, calc$a_post, calc$b_post)
    )
    
    df_long <- tidyr::pivot_longer(df, cols = c(Prior, Posteriori), 
                                   names_to = "Distribution", 
                                   values_to = "Densité")
    
    ggplot(df_long, aes(x = theta, y = Densité, color = Distribution)) +
      geom_line(linewidth = 1.5) +
      geom_vline(xintercept = calc$mle, linetype = "dashed", 
                 color = "blue", linewidth = 1) +
      geom_vline(xintercept = calc$mean_post, linetype = "dotted", 
                 color = "darkgreen", size = 1) +
      scale_color_manual(values = c("Prior" = "red", "Posteriori" = "black")) +
      labs(
        title = "Distributions a priori et a posteriori",
        subtitle = paste0("Ligne bleue : MLE (", round(calc$mle, 3), 
                          ") | Ligne verte : Moyenne a posteriori (", 
                          round(calc$mean_post, 3), ")"),
        x = expression(theta~"(Probabilité de survie)"),
        y = "Densité"
      ) +
      theme_minimal(base_size = 14) +
      theme(legend.position = "top")
  })
}

# Lancement de l'application
shinyApp(ui = ui, server = server)