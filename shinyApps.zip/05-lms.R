library(shiny)
library(ggplot2)
library(dplyr)
library(tidyr)

library(brms)
library(posterior)
library(bayesplot)
library(loo)

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

safe_int <- function(x, minv, maxv) {
  x <- as.integer(round(x))
  max(minv, min(maxv, x))
}

make_priors <- function(use_default = TRUE, sd_beta = 1.5, rate_sigma = 1) {
  if (use_default) return(NULL)
  
  c(
    set_prior(paste0("normal(0, ", sd_beta, ")"), class = "Intercept"),
    set_prior(paste0("normal(0, ", sd_beta, ")"), class = "b"),
    set_prior(paste0("exponential(", rate_sigma, ")"), class = "sigma")
  )
}

simulate_data <- function(n, beta0, beta1, sigma, seed, standardize_x = TRUE) {
  set.seed(seed)
  
  x_raw <- rnorm(n)
  if (standardize_x) {
    x <- as.numeric(scale(x_raw))
  } else {
    x <- x_raw
  }
  
  y <- beta0 + beta1 * x + rnorm(n, 0, sigma)
  
  data.frame(y = y, x = x)
}

posterior_ribbon <- function(fit, x_grid) {
  draws <- as_draws_df(fit)
  
  mu <- outer(draws$b_Intercept, rep(1, length(x_grid))) +
    outer(draws$b_x, x_grid)
  
  tibble(
    x = x_grid,
    mean  = apply(mu, 2, mean),
    lower = apply(mu, 2, quantile, 0.025),
    upper = apply(mu, 2, quantile, 0.975)
  )
}

prior_lines_df <- function(x_vals, n_lines, sd_beta) {
  b0 <- rnorm(n_lines, 0, sd_beta)
  b1 <- rnorm(n_lines, 0, sd_beta)
  
  bind_rows(lapply(seq_len(n_lines), function(i) {
    tibble(
      x = x_vals,
      y = b0[i] + b1[i] * x_vals,
      line = factor(i)
    )
  }))
}

summarise_fit <- function(fit, true_vals) {
  s <- summary(fit)
  
  fixed <- as.data.frame(s$fixed)
  fixed$Parameter <- rownames(fixed)
  
  sigma <- as.data.frame(s$spec_pars)
  sigma$Parameter <- rownames(sigma)
  
  tab <- bind_rows(fixed, sigma) |>
    transmute(
      Parameter = recode(Parameter,
                         "Intercept" = "Intercept (beta0)",
                         "x" = "Slope (beta1)",
                         "sigma" = "sigma"),
      true = c(true_vals$beta0, true_vals$beta1, true_vals$sigma),
      mean = Estimate,
      low = `l-95% CI`,
      high = `u-95% CI`,
      Rhat = Rhat,
      ESS = Bulk_ESS
    )
  
  tab
}

compute_ppc <- function(fit, y_obs) {
  yrep <- posterior_predict(fit, draws = 100)
  pval <- mean(rowMeans(yrep) >= mean(y_obs))
  list(yrep = yrep, pval = pval)
}

# ------------------------------------------------------------
# UI
# ------------------------------------------------------------

ui <- fluidPage(
  titlePanel("Chapitre 5 : régression linéaire simple"),
  h4("Simuler → Ajuster → Diagnostiquer → Comparer"),
  
  sidebarLayout(
    sidebarPanel(
      h4("1) Données"),
      numericInput("n", "n", 100, 20, 300),
      fluidRow(
        column(4, numericInput("beta0", "beta0", 0.1)),
        column(4, numericInput("beta1", "beta1", 1)),
        column(4, numericInput("sigma", "sigma", 0.5, min = 0.01))
      ),
      numericInput("seed", "seed", 666),
      checkboxInput("standardize_x", "Centrer / réduire x", TRUE),
      actionButton("sim", "Simuler"),
      
      hr(),
      
      h4("2) Priors"),
      radioButtons(
        "prior_mode", NULL,
        c("Priors brms par défaut" = "default",
          "Priors faiblement informatifs" = "weak"),
        selected = "weak"
      ),
      conditionalPanel(
        condition = "input.prior_mode == 'weak'",
        sliderInput("sd_beta", "sd(beta0, beta1)", 0.2, 10, 1.5),
        sliderInput("rate_sigma", "rate(sigma)", 0.1, 5, 1)
      ),
      
      hr(),
      
      h4("3) MCMC"),
      sliderInput("chains", "chains", 1, 4, 4),
      sliderInput("iter", "iter", 1000, 4000, 2000, step = 500),
      sliderInput("warmup", "warmup", 200, 2000, 1000, step = 200),
      sliderInput("cores", "cores", 1, 4, 2),
      
      actionButton("fit", "Lancer brms", class = "btn-success"),
      
      hr(),
      
      h4("4) Comparaison"),
      checkboxInput("fit_null", "Ajuster y ~ 1", TRUE),
      checkboxInput("do_loo", "Calculer LOO", TRUE),
      checkboxInput("do_waic", "Calculer WAIC", TRUE)
    ),
    
    mainPanel(
      plotOutput("plot_fit", height = 350),
      tableOutput("tab_params"),
      hr(),
      fluidRow(
        column(6, plotOutput("plot_prior", height = 300)),
        column(6, plotOutput("plot_ppc", height = 300))
      ),
      uiOutput("ppc_text"),
      hr(),
      tableOutput("tab_compare"),
      uiOutput("compare_text")
    )
  )
)

# ------------------------------------------------------------
# Server
# ------------------------------------------------------------

server <- function(input, output, session) {
  
  rv <- reactiveValues(data = NULL, fit1 = NULL, fit0 = NULL, ppc = NULL)
  
  observeEvent(input$sim, {
    rv$data <- simulate_data(
      input$n, input$beta0, input$beta1,
      input$sigma, input$seed, input$standardize_x
    )
    rv$fit1 <- rv$fit0 <- rv$ppc <- NULL
  })
  
  observeEvent(input$fit, {
    req(rv$data)
    
    iter <- safe_int(input$iter, 1000, 4000)
    warmup <- safe_int(input$warmup, 200, iter - 1)
    
    pri <- make_priors(
      input$prior_mode == "default",
      input$sd_beta, input$rate_sigma
    )
    
    rv$fit1 <- brm(
      y ~ x,
      data = rv$data,
      family = gaussian(),
      prior = pri,
      chains = input$chains,
      iter = iter,
      warmup = warmup,
      cores = input$cores,
      refresh = 0,
      seed = input$seed
    )
    
    if (input$fit_null) {
      pri0 <- if (input$prior_mode == "default") NULL else
        c(
          set_prior(paste0("normal(0, ", input$sd_beta, ")"), class = "Intercept"),
          set_prior(paste0("exponential(", input$rate_sigma, ")"), class = "sigma")
        )
      
      rv$fit0 <- brm(
        y ~ 1,
        data = rv$data,
        family = gaussian(),
        prior = pri0,
        chains = input$chains,
        iter = iter,
        warmup = warmup,
        cores = input$cores,
        refresh = 0,
        seed = input$seed
      )
    }
    
    rv$ppc <- compute_ppc(rv$fit1, rv$data$y)
  })
  
  output$plot_fit <- renderPlot({
    req(rv$data)
    
    p <- ggplot(rv$data, aes(x, y)) +
      geom_point(alpha = 0.6) +
      geom_abline(intercept = input$beta0, slope = input$beta1,
                  linetype = "dashed") +
      theme_minimal()
    
    if (!is.null(rv$fit1)) {
      xg <- seq(min(rv$data$x), max(rv$data$x), length.out = 100)
      pred <- posterior_ribbon(rv$fit1, xg)
      p <- p +
        geom_ribbon(data = pred,
                    aes(x, ymin = lower, ymax = upper),
                    inherit.aes = FALSE, alpha = 0.2) +
        geom_line(data = pred, aes(x, y = mean),
                  inherit.aes = FALSE)
    }
    
    p
  })
  
  output$tab_params <- renderTable({
    req(rv$fit1)
    summarise_fit(
      rv$fit1,
      list(beta0 = input$beta0,
           beta1 = input$beta1,
           sigma = input$sigma)
    ) |>
      mutate(across(where(is.numeric), ~ round(.x, 3)))
  })
  
  output$plot_prior <- renderPlot({
    req(rv$data)
    sd_use <- if (input$prior_mode == "weak") input$sd_beta else 5
    xg <- seq(min(rv$data$x), max(rv$data$x), length.out = 80)
    
    ggplot(prior_lines_df(xg, 60, sd_use),
           aes(x, y, group = line)) +
      geom_line(alpha = 0.25) +
      theme_minimal() +
      labs(title = "Prior predictive (droites)")
  })
  
  output$plot_ppc <- renderPlot({
    req(rv$ppc)
    ppc_dens_overlay(rv$data$y, rv$ppc$yrep[1:50, ])
  })
  
  output$ppc_text <- renderUI({
    req(rv$ppc)
    HTML(paste0(
      "<b>Bayesian p-value (moyenne)</b> : ",
      round(rv$ppc$pval, 2),
      "<br><small>≈ 0.5 : OK · proche de 0 ou 1 : problème potentiel</small>"
    ))
  })
  
  output$tab_compare <- renderTable({
    req(rv$fit0, rv$fit1)
    
    rows <- list()
    
    if (input$do_waic) {
      w0 <- waic(rv$fit0)$estimates["waic", "Estimate"]
      w1 <- waic(rv$fit1)$estimates["waic", "Estimate"]
      rows[[1]] <- data.frame(
        Critere = "WAIC",
        y_1 = round(w0, 2),
        y_x = round(w1, 2),
        Delta = round(w0 - w1, 2)
      )
    }
    
    if (input$do_loo) {
      l0 <- loo(rv$fit0)$estimates["elpd_loo", "Estimate"]
      l1 <- loo(rv$fit1)$estimates["elpd_loo", "Estimate"]
      rows[[length(rows) + 1]] <- data.frame(
        Critere = "LOO (elpd)",
        y_1 = round(l0, 2),
        y_x = round(l1, 2),
        Delta = round(l1 - l0, 2)
      )
    }
    
    bind_rows(rows)
  }, colnames = TRUE)
  
  output$compare_text <- renderUI({
    req(rv$fit0, rv$fit1)
    HTML("<b>Conclusion :</b> le modèle avec x doit être préféré si Δ > 0 (LOO) ou Δ < 0 (WAIC).")
  })
}

shinyApp(ui, server)
