library(shiny)
library(ggplot2)
library(dplyr)
library(coda)

# Données
y <- 19
n <- 57

loglikelihood <- function(x, p){
  dbinom(x = x, size = n, prob = p, log = TRUE)
}

logprior <- function(p){
  dunif(x = p, min = 0, max = 1, log = TRUE)  # prior uniforme
}

posterior <- function(x, p){
  loglikelihood(x, p) + logprior(p)
}

move <- function(x, away = 1){
  logitx <- log(x / (1 - x))
  logit_candidate <- logitx + rnorm(1, 0, away)
  plogis(logit_candidate)
}

metropolis <- function(steps = 100, inits = 0.5, away = 1){
  theta.post <- rep(NA_real_, steps)
  theta.post[1] <- inits
  
  for (t in 2:steps){
    theta_star <- move(theta.post[t-1], away)
    logR <- posterior(y, theta_star) - posterior(y, theta.post[t-1])
    R <- exp(logR)
    X <- runif(1)
    theta.post[t] <- ifelse(X < min(1, R), theta_star, theta.post[t-1])
  }
  theta.post
}

ui <- fluidPage(
  titlePanel("Chapitre 2 : un algorithme MCMC"),
  
  sidebarLayout(
    sidebarPanel(
      h4("Paramètres MCMC"),
      sliderInput("steps",
                  "Nombre d'itérations:",
                  min = 100, max = 5000, value = 1000, step = 100),
      sliderInput("burnin",
                  "Burn-in:",
                  min = 0, max = 999, value = 300, step = 50),
      sliderInput("away",
                  "Écart-type de la proposition:",
                  min = 0.1, max = 10, value = 1, step = 0.1),
      sliderInput("n_chains",
                  "Nombre de chaînes:",
                  min = 1, max = 4, value = 2, step = 1),
      
      hr(),
      h4("Valeurs initiales"),
      uiOutput("init_sliders"),
      
      hr(),
      actionButton("run", "Lancer les chaînes", class = "btn-primary")
    ),
    
    mainPanel(
      fluidRow(
        column(6, plotOutput("trace_plot", height = "380px")),
        column(6, plotOutput("histogram",  height = "380px"))
      ),
      hr(),
      h4("Indicateurs numériques"),
      p("Tableau par chaîne (après burn-in) + indicateurs globaux (pool de toutes les chaînes)."),
      tableOutput("metrics_table"),
      br(),
      uiOutput("metrics_notes")
    )
  )
)

server <- function(input, output, session) {
  
  # burnin <= steps - 1
  observe({
    req(input$steps)
    max_burn <- max(0, input$steps - 1)
    updateSliderInput(session, "burnin", max = max_burn)
    if (input$burnin > max_burn) {
      updateSliderInput(session, "burnin", value = max_burn)
    }
  })
  
  # sliders init
  output$init_sliders <- renderUI({
    nC <- input$n_chains
    lapply(1:nC, function(i) {
      sliderInput(paste0("init", i),
                  paste("Chaîne", i, ":"),
                  min = 0.01, max = 0.99,
                  value = runif(1, 0.2, 0.8),
                  step = 0.01)
    })
  })
  
  chains_data <- eventReactive(input$run, {
    n_chains <- input$n_chains
    steps <- input$steps
    away <- input$away
    
    inits <- sapply(1:n_chains, function(i) input[[paste0("init", i)]])
    
    results <- vector("list", n_chains)
    for (i in 1:n_chains) {
      results[[i]] <- metropolis(steps = steps, inits = inits[i], away = away)
    }
    
    df <- data.frame(
      iteration = rep(1:steps, n_chains),
      value     = unlist(results),
      chain     = factor(rep(paste("Chaîne", 1:n_chains), each = steps))
    )
    
    list(df = df, results = results, inits = inits)
  })
  
  output$trace_plot <- renderPlot({
    req(chains_data())
    df <- chains_data()$df
    burnin <- input$burnin
    
    colors <- c("#3B9AB2", "#EBCC2A", "#F21A00", "#78B7C5")
    
    p <- ggplot(df, aes(x = iteration, y = value, color = chain)) +
      geom_line(linewidth = 0.6) +
      scale_color_manual(values = colors[1:input$n_chains]) +
      labs(title = "Trace plot des chaînes MCMC",
           x = "Itérations",
           y = "theta (probabilité de survie)",
           color = "") +
      theme_minimal(base_size = 12) +
      theme(legend.position = "top")
    
    if (burnin > 0) {
      p <- p +
        annotate("rect", xmin = 0, xmax = burnin,
                 ymin = -Inf, ymax = Inf,
                 alpha = 0.2, fill = "gray") +
        annotate("text", x = burnin/2, y = 0.05,
                 label = "Burn-in", size = 4, color = "gray30")
    }
    p
  })
  
  output$histogram <- renderPlot({
    req(chains_data())
    df <- chains_data()$df
    burnin <- input$burnin
    
    df_post <- df %>% filter(iteration > burnin)
    validate(need(nrow(df_post) > 10, "Pas assez d’itérations après burn-in. Réduis le burn-in ou augmente steps."))
    
    colors <- c("#3B9AB2", "#EBCC2A", "#F21A00", "#78B7C5")
    
    ggplot(df_post, aes(x = value, fill = chain)) +
      geom_histogram(bins = 30, alpha = 0.6, position = "identity") +
      geom_vline(xintercept = mean(df_post$value),
                 linetype = "dashed", linewidth = 0.9, color = "black") +
      scale_fill_manual(values = colors[1:input$n_chains]) +
      labs(title = "Distribution a posteriori (après burn-in)",
           x = "theta",
           y = "Fréquence",
           fill = "") +
      theme_minimal(base_size = 12) +
      theme(legend.position = "top")
  })
  
  metrics <- reactive({
    req(chains_data())
    burnin <- input$burnin
    results <- chains_data()$results
    n_chains <- input$n_chains
    
    # post burn-in vectors (safe)
    post <- lapply(results, function(x) {
      if (burnin <= 0) return(x)
      if (burnin >= length(x)) return(numeric(0))
      x[(burnin + 1):length(x)]
    })
    
    lens <- vapply(post, length, 1L)
    if (any(lens < 10)) {
      return(list(ok = FALSE, msg = "Pas assez de points après burn-in pour au moins une chaîne."))
    }
    
    # per-chain indicators
    chain_names <- paste0("Chaîne ", 1:n_chains)
    mean_c  <- vapply(post, mean, numeric(1))
    q025_c  <- vapply(post, function(x) quantile(x, 0.025), numeric(1))
    q975_c  <- vapply(post, function(x) quantile(x, 0.975), numeric(1))
    neff_c  <- vapply(post, effectiveSize, numeric(1))
    acc_c   <- vapply(results, function(chain) mean(diff(chain) != 0), numeric(1))
    
    # global (pooled)
    pooled <- unlist(post)
    mean_g <- mean(pooled)
    q025_g <- quantile(pooled, 0.025)
    q975_g <- quantile(pooled, 0.975)
    neff_g <- effectiveSize(pooled)
    acc_g  <- mean(acc_c)
    
    # Rhat (Gelman-Rubin) if >= 2 chains
    if (n_chains >= 2) {
      mlist <- mcmc.list(lapply(post, mcmc))
      rhat <- gelman.diag(mlist, autoburnin = FALSE)$psrf[1]
    } else {
      rhat <- NA_real_
    }
    
    # Build table
    tab <- data.frame(
      élément = c(chain_names, "Global (pool)"),
      moyenne = c(mean_c, mean_g),
      IC_95   = c(paste0("[", round(q025_c, 3), ", ", round(q975_c, 3), "]"),
                  paste0("[", round(q025_g, 3), ", ", round(q975_g, 3), "]")),
      neff    = c(round(neff_c), round(neff_g)),
      accept  = c(round(acc_c, 2), round(acc_g, 2)),
      Rhat    = c(rep(NA_real_, n_chains), rhat)
    )
    
    list(ok = TRUE, table = tab, rhat = rhat, neff_g = neff_g, acc_g = acc_g)
  })
  
  output$metrics_table <- renderTable({
    m <- metrics()
    validate(need(m$ok, m$msg))
    m$table
  }, striped = TRUE, bordered = TRUE, spacing = "s", digits = 3)
  
  output$metrics_notes <- renderUI({
    m <- metrics()
    if (!m$ok) return(NULL)
    
    # simple guidance
    rhat_txt <- if (is.na(m$rhat)) {
      "R-hat : non calculé (une seule chaîne)."
    } else {
      paste0("R-hat global : ", round(m$rhat, 3),
             if (m$rhat < 1.1) " ✓" else " ⚠")
    }
    
    neff_txt <- paste0("n.eff global : ", round(m$neff_g),
                       if (m$neff_g >= 400) " ✓" else " ⚠")
    
    acc_txt <- paste0("Taux d’acceptation moyen : ", round(m$acc_g, 2),
                      if (m$acc_g >= 0.2 && m$acc_g <= 0.4) " ✓" else " ⚠")
    
    tagList(
      tags$ul(
        tags$li(rhat_txt),
        tags$li(neff_txt),
        tags$li(acc_txt)
      ),
      tags$small("✓ = généralement OK ; ⚠ = à surveiller.")
    )
  })
}

shinyApp(ui = ui, server = server)
