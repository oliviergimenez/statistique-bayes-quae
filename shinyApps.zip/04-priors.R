library(shiny)
library(ggplot2)

# --- Helpers ----
beta_posterior_params <- function(a, b, y, n) {
  list(a_post = a + y, b_post = b + (n - y))
}

# --- UI ----
ui <- fluidPage(
  tags$style(HTML("
    .block-title { font-size: 18px; font-weight: 700; margin-top: 4px; }
    .block-sub  { font-size: 14px; color: #555; margin-bottom: 8px; }
    .metric     { font-size: 14px; }
    .metric b   { font-weight: 700; }
    .sep { margin: 16px 0; }
  ")),
  titlePanel(
    tagList(
      h2("Chapitre 4 : sensibilité au prior"),
    )
  ),
  
  sidebarLayout(
    sidebarPanel(
      tags$div(class="block-title", "Bloc A — Prior vs posterior"),
      tags$div(class="block-sub", "Choisir un prior Beta(a,b) et observer son influence."),
      
      fluidRow(
        column(6, numericInput("yA", "y", value = 19, min = 0, step = 1)),
        column(6, numericInput("nA", "n", value = 57, min = 1, step = 1))
      ),
      fluidRow(
        column(6, numericInput("aA", "a (prior)", value = 1, min = 0.1, step = 0.1)),
        column(6, numericInput("bA", "b (prior)", value = 1, min = 0.1, step = 0.1))
      ),
      selectInput(
        "presetA", "Priors rapides",
        choices = c(
          "—" = "none",
          "Uniforme Beta(1,1)" = "b11",
          "Jeffreys Beta(0.5,0.5)" = "b0505",
          "Modéré Beta(5,5)" = "b55",
          "Fort Beta(20,1)" = "b201"
        ),
        selected = "none"
      ),
      
      tags$hr(class="sep"),
      
      tags$div(class="block-title", "Bloc B — Analyse de sensibilité"),
      tags$div(class="block-sub", "Comparer plusieurs priors et deux tailles d’échantillon."),
      
      checkboxGroupInput(
        "priorsB", "Priors à comparer",
        choices = c(
          "Beta(1,1)" = "b11",
          "Beta(5,5)" = "b55",
          "Beta(20,1)" = "b201",
          "Jeffreys Beta(0.5,0.5)" = "b0505"
        ),
        selected = c("b11", "b55", "b201")
      ),
      fluidRow(
        column(6, numericInput("ySmall", "y (petit)", value = 2, min = 0, step = 1)),
        column(6, numericInput("nSmall", "n (petit)", value = 6, min = 1, step = 1))
      ),
      fluidRow(
        column(6, numericInput("yBig", "y (grand)", value = 19, min = 0, step = 1)),
        column(6, numericInput("nBig", "n (grand)", value = 57, min = 1, step = 1))
      )
    ),
    
    mainPanel(
      tags$div(class="block-title", "Bloc A — Prior et posterior"),
      fluidRow(
        column(8, plotOutput("plotA", height = 320)),
        column(4, uiOutput("metricsA"))
      ),
      
      tags$hr(class="sep"),
      
      tags$div(class="block-title", "Bloc B — Sensibilité au prior"),
      plotOutput("plotB", height = 340),
      tableOutput("tableB")
    )
  )
)

# --- Server ----
server <- function(input, output, session) {
  
  # sécurité y <= n
  observe({
    updateNumericInput(session, "yA", value = min(input$yA, input$nA))
    updateNumericInput(session, "ySmall", value = min(input$ySmall, input$nSmall))
    updateNumericInput(session, "yBig", value = min(input$yBig, input$nBig))
  })
  
  # presets Bloc A
  observeEvent(input$presetA, {
    switch(input$presetA,
           "b11"   = { updateNumericInput(session, "aA", 1);   updateNumericInput(session, "bA", 1) },
           "b0505" = { updateNumericInput(session, "aA", 0.5); updateNumericInput(session, "bA", 0.5) },
           "b55"   = { updateNumericInput(session, "aA", 5);   updateNumericInput(session, "bA", 5) },
           "b201"  = { updateNumericInput(session, "aA", 20);  updateNumericInput(session, "bA", 1) }
    )
  })
  
  # --- Bloc A ----
  blocA <- reactive({
    y <- input$yA; n <- input$nA
    a <- input$aA; b <- input$bA
    
    post <- beta_posterior_params(a, b, y, n)
    list(
      y = y, n = n, a = a, b = b,
      a_post = post$a_post,
      b_post = post$b_post,
      mu_prior = a / (a + b),
      mu_hat = y / n,
      w = n / (a + b + n),
      mu_post = post$a_post / (post$a_post + post$b_post)
    )
  })
  
  output$metricsA <- renderUI({
    A <- blocA()
    tagList(
      tags$div(class="metric", HTML(paste0("<b>Prior</b> : Beta(", A$a, ", ", A$b, ")"))),
      tags$div(class="metric", HTML(paste0("<b>Posterior</b> : Beta(", A$a_post, ", ", A$b_post, ")"))),
      tags$hr(),
      tags$div(class="metric", HTML(paste0("<b>Moyenne prior</b> = ", round(A$mu_prior, 3)))),
      tags$div(class="metric", HTML(paste0("<b>y/n</b> = ", round(A$mu_hat, 3)))),
      tags$div(class="metric", HTML(paste0("<b>w</b> = ", round(A$w, 3)))),
      tags$div(class="metric", HTML(paste0("<b>Moyenne a posteriori</b> = ", round(A$mu_post, 3)))),
      tags$hr(),
      tags$div(class="metric",
               HTML("Lecture : plus <b>w</b> est proche de 1, plus les données dominent."))
    )
  })
  
  output$plotA <- renderPlot({
    A <- blocA()
    x <- seq(0.001, 0.999, length.out = 800)
    df <- rbind(
      data.frame(theta = x, dens = dbeta(x, A$a, A$b), Type = "Prior"),
      data.frame(theta = x, dens = dbeta(x, A$a_post, A$b_post), Type = "Posterior")
    )
    
    ggplot(df, aes(theta, dens, linetype = Type)) +
      geom_line(linewidth = 1) +
      geom_vline(xintercept = A$mu_hat, linetype = "dotted") +
      labs(x = "theta", y = "Densité", linetype = "") +
      theme_minimal(base_size = 13)
  })
  
  # --- Bloc B ----
  prior_map <- function(code) {
    switch(code,
           b11   = list(a=1,   b=1,   name="Beta(1,1)"),
           b55   = list(a=5,   b=5,   name="Beta(5,5)"),
           b201  = list(a=20,  b=1,   name="Beta(20,1)"),
           b0505 = list(a=0.5, b=0.5, name="Jeffreys Beta(0.5,0.5)")
    )
  }
  
  output$plotB <- renderPlot({
    priors <- input$priorsB
    validate(need(length(priors) > 0, "Sélectionner au moins un prior."))
    
    rows <- list()
    x <- seq(0.001, 0.999, length.out = 600)
    
    for (p in priors) {
      pm <- prior_map(p)
      for (s in c("petit", "grand")) {
        y <- if (s == "petit") input$ySmall else input$yBig
        n <- if (s == "petit") input$nSmall else input$nBig
        post <- beta_posterior_params(pm$a, pm$b, y, n)
        
        rows[[length(rows)+1]] <- data.frame(
          theta = x,
          dens = dbeta(x, post$a_post, post$b_post),
          Prior = pm$name,
          Echantillon = paste0(s, " (n=", n, ", y=", y, ")")
        )
      }
    }
    
    df <- do.call(rbind, rows)
    
    ggplot(df, aes(theta, dens, linetype = Prior)) +
      geom_line(linewidth = 1) +
      facet_wrap(~ Echantillon, ncol = 2) +
      labs(x = "theta", y = "Densité", linetype = "") +
      theme_minimal(base_size = 13) +
      theme(legend.position = "top")
  })
  
  output$tableB <- renderTable({
    priors <- input$priorsB
    rows <- list()
    
    for (p in priors) {
      pm <- prior_map(p)
      for (s in c("petit", "grand")) {
        y <- if (s == "petit") input$ySmall else input$yBig
        n <- if (s == "petit") input$nSmall else input$nBig
        post <- beta_posterior_params(pm$a, pm$b, y, n)
        
        mu <- post$a_post / (post$a_post + post$b_post)
        ci <- qbeta(c(0.025, 0.975), post$a_post, post$b_post)
        
        rows[[length(rows)+1]] <- data.frame(
          Prior = pm$name,
          Donnees = s,
          Moyenne = round(mu, 3),
          IC_inf = round(ci[1], 3),
          IC_sup = round(ci[2], 3)
        )
      }
    }
    do.call(rbind, rows)
  }, striped = TRUE, bordered = TRUE, spacing = "s")
}

shinyApp(ui, server)
