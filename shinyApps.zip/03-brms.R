
library(shiny)
library(ggplot2)
library(brms)
library(posterior)

ui <- fluidPage(
  titlePanel(
    tagList(
      h2("Chapitre 3 : introduction à brms"),
      tags$div(
        HTML(
          'Voir aussi l’app Shiny dédiée 
         <a href="https://fweber144.github.io/shinybrms/" target="_blank">
         shinybrms</a> pour une exploration plus avancée.'
        ),
        style = "font-size: 16px; margin-top: 6px; color: #555;"
      )
    )
  )
  ,

  sidebarLayout(
    sidebarPanel(
      h4("Données"),
      numericInput("y", "y (succès / survivants)", value = 19, min = 0, step = 1),
      numericInput("n", "n (essais / individus)", value = 57, min = 1, step = 1),

      hr(),
      h4("MCMC (brms/Stan)"),
      numericInput("chains", "Nombre de chaînes", value = 3, min = 1, step = 1),
      numericInput("iter", "Itérations totales / chaîne", value = 2000, min = 200, step = 100),
      numericInput("warmup", "Warmup / chaîne", value = 300, min = 0, step = 50),
      numericInput("seed", "Seed", value = 123, min = 1, step = 1),

      hr(),
      h4("Prior sur l'Intercept (beta, échelle logit)"),
      radioButtons(
        "prior_mode", NULL,
        choices = c("Par défaut brms" = "default", "Normal(0, sd)" = "normal"),
        selected = "default"
      ),
      conditionalPanel(
        condition = "input.prior_mode == 'normal'",
        sliderInput("sd_prior", "sd", min = 0.2, max = 5, value = 1.5, step = 0.1)
      ),

      hr(),
      actionButton("run", "Lancer brms", class = "btn-primary"),
      br(), br(),
      verbatimTextOutput("run_status"),
      tags$hr(),
      tags$div(
        HTML(
          'Aller plus loin : 
     <a href="https://fweber144.github.io/shinybrms/" target="_blank">
     shinybrms</a>.'
        ),
        style = "font-size: 15px; color: #555;"
      )      
    ),

    mainPanel(
      h4("1) Code brms (copiable)"),
      verbatimTextOutput("code_call"),

      hr(),
      h4("2) Priors utilisés"),
      verbatimTextOutput("prior_sum"),

      hr(),
      h4("3) Résumé & diagnostics (beta et theta)"),
      tableOutput("diag_table"),

      hr(),
      h4("4) Posterior de theta (probabilité)"),
      plotOutput("theta_hist", height = 320)
    )
  )
)

server <- function(input, output, session) {

  # S'assurer que 0 <= y <= n
  observe({
    n <- as.integer(max(1, input$n))
    y <- as.integer(input$y)
    y2 <- min(max(y, 0), n)
    if (!identical(y, y2)) updateNumericInput(session, "y", value = y2)
  })

  # Prior brms 
  prior_obj <- reactive({
    if (input$prior_mode == "normal") {
      brms::set_prior(paste0("normal(0,", input$sd_prior, ")"), class = "Intercept")
    } else {
      NULL
    }
  })

  # Code copiable
  output$code_call <- renderText({
    y <- as.integer(input$y)
    n <- as.integer(input$n)

    base <- paste0(
      "dat <- data.frame(y = ", y, ", n = ", n, ")\n",
      "fit <- brm(\n",
      "  y | trials(n) ~ 1,\n",
      "  family = binomial('logit'),\n",
      "  data = dat,\n"
    )

    prior_line <- if (input$prior_mode == "normal") {
      paste0("  prior = set_prior('normal(0,", input$sd_prior, ")', class = 'Intercept'),\n")
    } else {
      ""
    }

    tail <- paste0(
      "  chains = ", input$chains, ",\n",
      "  iter = ", input$iter, ",\n",
      "  warmup = ", input$warmup, ",\n",
      "  seed = ", input$seed, ",\n",
      "  refresh = 0\n",
      ")\n"
    )

    paste0(base, prior_line, tail)
  })

  # Fit brms
  fit <- eventReactive(input$run, {
    validate(
      need(input$iter > input$warmup, "iter doit être > warmup."),
      need(input$chains >= 1, "chains doit être >= 1.")
    )

    dat <- data.frame(y = as.integer(input$y), n = as.integer(input$n))

    # Masquer messages/warnings de compilation dans l'UI
    withCallingHandlers(
      {
        if (is.null(prior_obj())) {
          brm(
            y | trials(n) ~ 1,
            family = binomial("logit"),
            data = dat,
            chains = input$chains,
            iter = input$iter,
            warmup = input$warmup,
            seed = input$seed,
            refresh = 0
          )
        } else {
          brm(
            y | trials(n) ~ 1,
            family = binomial("logit"),
            data = dat,
            prior = prior_obj(),
            chains = input$chains,
            iter = input$iter,
            warmup = input$warmup,
            seed = input$seed,
            refresh = 0
          )
        }
      },
      message = function(m) invokeRestart("muffleMessage"),
      warning = function(w) invokeRestart("muffleWarning")
    )
  })

  output$run_status <- renderText({
    if (input$run == 0) "Prêt. Cliquer sur « Lancer brms »."
    else "Fit lancé / mis à jour."
  })

  # Priors
  output$prior_sum <- renderPrint({
    req(fit())
    prior_summary(fit())
  })

  # Helper: construire un draws_array de theta (pour Rhat/ESS)
  theta_draws_array <- reactive({
    req(fit())
    da <- brms::as_draws_array(fit())  # iters x chains x variables
    if (!("b_Intercept" %in% dimnames(da)[[3]])) {
      stop("Impossible de trouver b_Intercept dans les tirages.")
    }
    beta <- da[, , "b_Intercept"]
    theta <- plogis(beta)

    # convertir en draws_array (iters x chains x 1 var)
    theta_arr <- array(theta, dim = c(dim(beta)[1], dim(beta)[2], 1))
    dimnames(theta_arr) <- list(NULL, NULL, "theta")
    posterior::as_draws_array(theta_arr)
  })

  # Tableau diagnostics beta + theta
  output$diag_table <- renderTable({
    req(fit())

    s <- summary(fit())
    fixed <- as.data.frame(s$fixed)
    fixed$Param <- rownames(fixed)
    rownames(fixed) <- NULL

    # on garde uniquement l'intercept
    fixed <- fixed[fixed$Param == "Intercept", , drop = FALSE]

    keep_cols <- intersect(
      c("Param", "Estimate", "Est.Error", "l-95% CI", "u-95% CI", "Rhat", "Bulk_ESS"),
      colnames(fixed)
    )
    beta_row <- fixed[, keep_cols, drop = FALSE]
    beta_row$Param <- "beta (Intercept, logit)"

    # theta row (calculé depuis draws)
    td <- theta_draws_array()
    theta_flat <- as.numeric(td)

    theta_mean <- mean(theta_flat)
    theta_sd   <- sd(theta_flat)
    theta_ci   <- quantile(theta_flat, probs = c(0.025, 0.975), names = FALSE)

    theta_rhat <- as.numeric(posterior::rhat(td))[1]
    theta_ess  <- as.numeric(posterior::ess_bulk(td))[1]

    theta_row <- data.frame(
      Param = "theta (plogis(beta))",
      Estimate = theta_mean,
      Est.Error = theta_sd,
      `l-95% CI` = theta_ci[1],
      `u-95% CI` = theta_ci[2],
      Rhat = theta_rhat,
      Bulk_ESS = theta_ess,
      check.names = FALSE
    )

    # Harmoniser colonnes si brms n'affiche pas certaines colonnes (selon versions)
    out <- bind_rows(beta_row, theta_row)

    # Si certaines colonnes manquent (rare), on les ajoute
    wanted <- c("Param", "Estimate", "Est.Error", "l-95% CI", "u-95% CI", "Rhat", "Bulk_ESS")
    for (nm in wanted) if (!nm %in% names(out)) out[[nm]] <- NA_real_

    out[, wanted, drop = FALSE]
  }, striped = TRUE, bordered = TRUE, spacing = "s", digits = 3)

  # Histogramme theta
  output$theta_hist <- renderPlot({
    td <- theta_draws_array()
    df <- data.frame(theta = as.numeric(td))

    ggplot(df, aes(theta)) +
      geom_histogram(bins = 30, color = "white") +
      labs(x = "theta", y = "Fréquence") +
      theme_minimal(base_size = 12)
  })
}

shinyApp(ui, server)
