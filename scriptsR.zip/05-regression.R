#' # La régression

library(tidyverse)

#' ## Introduction 

#' ## La régression linéaire

#' ### Le modèle

#' ### Simuler des données

beta0 <- 0.1 # valeur vraie de l'intercept
beta1 <- 1 # valeur vraie du coefficient de x
sigma <- 0.5 # écart-type des erreurs

set.seed(666) # pour rendre la simulation reproductible
n <- 100 # nombre d'observations
x <- rnorm(n = n, mean = 0, sd = 1) # covariable x simulée selon une loi normale standard

epsilon <- rnorm(n, mean = 0, sd = sigma) # génère les erreurs normales
y <- beta0 + beta1 * x + epsilon # ajoute les erreurs à la relation linéaire
data <- data.frame(y = y, x = x)

## Données simulées (n = 100) selon le modèle y_i = beta_0 + beta_1 x_i 
## + epsilon_i, avec beta_0 = 0.1, beta_1 = 1 et 
## sigma = 1. La droite rouge correspond à la droite de régression.
ggplot(data, aes(x = x, y = y)) +
  geom_point(alpha = 0.6) +
  geom_abline(intercept = beta0, slope = beta1, color = "red", size = 1.2) +
  labs(title = "",
       x = "x", 
       y = "y") +
  theme_minimal()

#' ### L'ajustement avec `brms`

library(brms)

lm.brms <- brm(y ~ x, 
               data = data, 
               family = gaussian,
               refresh = 0)

summary(lm.brms)

## Histogrammes des distributions a posteriori (colonne de gauche) et traces 
## (colonne de droite) des paramètres de la régression linéaire. Dans les 
## histogrammes, l’axe des abscisses représente les valeurs possibles du 
## paramètre estimé (intercept, pente ou écart-type) et l’axe des ordonnées 
## correspond à leur fréquence dans l’échantillon a posteriori. Dans les trace 
## plots, l’axe des abscisses indique le numéro d’itération du MCMC, tandis que 
## l’axe des ordonnées représente la valeur simulée du paramètre à chaque itération
plot(lm.brms)

#' ### Des priors faiblement informatifs

## Simulation de droites de régression issues des distributions a priori. 
## Chaque ligne correspond à un tirage des paramètres : intercept et pente ~ 
## N(0, 100).

# nombre de droites à simuler
n_lines <- 100

# tirages des intercepts et pentes selon les priors
intercepts <- rnorm(n_lines, mean = 0, sd = 100)
slopes <- rnorm(n_lines, mean = 0, sd = 100)

# création d'un data frame
lines_df <- data.frame()
for (i in 1:n_lines) {
  y_vals <- intercepts[i] + slopes[i] * x
  temp_df <- data.frame(x = x, y = y_vals, line = as.factor(i))
  lines_df <- rbind(lines_df, temp_df)
}

# tracé avec ggplot2
ggplot(lines_df, aes(x = x, y = y, group = line)) +
  geom_line(alpha = 0.3) +
  theme_minimal() +
  labs(x = "x", y = "y")

## Simulation de droites de régression issues des distributions a priori. 
## Chaque ligne correspond à un tirage des paramètres : intercept et 
## pente ~ N(0, 1.5).

# nombre de droites à simuler
n_lines <- 100

# tirages des intercepts et pentes selon les priors
intercepts <- rnorm(n_lines, mean = 0, sd = 1.5)
slopes <- rnorm(n_lines, mean = 0, sd = 1.5)

# création d'un data frame long pour ggplot
lines_df <- data.frame()
for (i in 1:n_lines) {
  y_vals <- intercepts[i] + slopes[i] * x
  temp_df <- data.frame(x = x, y = y_vals, line = as.factor(i))
  lines_df <- rbind(lines_df, temp_df)
}

# Tracé avec ggplot2
ggplot(lines_df, aes(x = x, y = y, group = line)) +
  geom_line(alpha = 0.3) +
  theme_minimal() +
  labs(x = "x", y = "y")


## Comparaison entre deux lois a priori pour l’écart-type sigma : une 
## loi uniforme U(0,5), qui donne la même densité entre 0 et 5, et 
## une loi exponentielle Exp(1), qui favorise les petites valeurs tout en 
# conservant une queue plus lourde.

# Séquence de valeurs pour sigma
x <- seq(0, 10, length.out = 1000)

# Calcul des densités
df <- tibble(
  sigma = x,
  `Exp(1)` = dexp(x, rate = 1),
  `U(0, 5)` = dunif(x, min = 0, max = 5)
)

# Passage au format long pour ggplot
df_long <- pivot_longer(df, cols = -sigma, names_to = "Distribution", values_to = "Densité")

# Tracé
ggplot(df_long, aes(x = sigma, y = Densité, color = Distribution)) +
  geom_line(size = 1.2) +
  labs(
    title = "",
    x = expression(sigma), y = "Densité",
    color = "Distribution"
  ) +
  theme_minimal(base_size = 14)

myprior <- c(
  prior(normal(0, 1.5), class = b), # prior sur le coefficient de x
  prior(normal(0, 1.5), class = Intercept), # prior sur l'intercept
  prior(exponential(1), class = sigma) # prior sur l'écart-type de l'erreur
)

lm.brms <- brm(y ~ x, 
               data = data, 
               family = gaussian,
               refresh = 0, 
               prior = myprior) # nos propres priors

summary(lm.brms)


#' ### L'ajustement par maximum de vraisemblance

# Valeurs vraies utilisées dans la simulation
true_beta0 <- 0.1
true_beta1 <- 1

# Modèle classique avec lm()
lm_fit <- lm(y ~ x, data = data)

# Extraire les résultats brms
brms_summary <- summary(lm.brms)
brms_estimates <- brms_summary$fixed

# Tableau comparatif des estimations

# Construire un data frame avec tous les résultats
results_df <- data.frame(
  Method = rep(c("lm", "brms"), each = 2),
  Parameter = rep(c("Intercept", "Slope"), times = 2),
  Estimate = c(
    coef(lm_fit)[1], coef(lm_fit)[2],                     # lm
    brms_estimates[, "Estimate"]                         # brms
  ),
  Lower = c(
    confint(lm_fit)[1,1], confint(lm_fit)[2,1],            # lm: IC 95% classique
    brms_estimates[, "l-95% CI"]                            # brms: IC 95% crédibles
  ),
  Upper = c(
    confint(lm_fit)[1,2], confint(lm_fit)[2,2],            # lm
    brms_estimates[, "u-95% CI"]                            # brms
  )
)

# Ajouter la vraie valeur comme une nouvelle méthode
true_values <- data.frame(
  Method = "True value",
  Parameter = c("Intercept", "Slope"),
  Estimate = c(true_beta0, true_beta1),
  Lower = NA,
  Upper = NA
)

# Combiner
results_df_full <- rbind(results_df, true_values)

## Comparaison des estimations des paramètres du modèle (intercept ou ordonnée 
## à l'origine et pente) selon les différentes méthodes (brms et lm). Les points 
## donnent les moyennes a posteriori pour brms, et l'estimation du maximum de 
## vraisemblance pour lm. On donne également les intervalles de crédibilité 
## (pour brms) et de confiance (pour lm) à 95%. La ligne en tirets noirs indique 
## la vraie valeur utilisée pour simuler les données.

library(patchwork)

# Séparer données observées (sans True value)
plot_data <- subset(results_df_full, Method != "True value")

# Plot pour Intercept
p_intercept <- ggplot(subset(plot_data, Parameter == "Intercept"), 
                      aes(x = Method, y = Estimate, color = Method)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = Lower, ymax = Upper), width = 0.2) +
  geom_hline(yintercept = true_beta0, linetype = "dashed", color = "black", size = 1) +
  labs(
    title = "Intercept",
    x = "",
    y = "Valeur estimée"
  ) +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none")

# Plot pour Slope
p_slope <- ggplot(subset(plot_data, Parameter == "Slope"), 
                  aes(x = Method, y = Estimate, color = Method)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = Lower, ymax = Upper), width = 0.2) +
  geom_hline(yintercept = true_beta1, linetype = "dashed", color = "black", size = 1) +
  labs(
    title = "Pente",
    x = "",
    y = "Valeur estimée"
  ) +
  theme_minimal(base_size = 14) +
  theme(legend.position = "none")

# Assembler côte à côte avec titre et sous-titre globaux
(p_intercept | p_slope) +
  plot_layout(guides = 'collect') & 
  plot_annotation(
    #    title = "Comparaison des estimations par méthode",
    #    subtitle = "Le tiret noir indique la vraie valeur du paramètre",
    theme = theme(plot.title = element_text(size = 16, face = "bold"),
                  plot.subtitle = element_text(size = 14))
  ) &
  theme(legend.position = "bottom") & guides(color = "none")

#' ## L'évaluation des modèles

## Ajustement du modèle linéaire par brms. La droite bleue est la régression 
## estimée, obtenue en fixant l'ordonnée à l'origine et la pente à leur moyenne 
## a posteriori, entourée de son intervalle de crédibilité à 95 %.

# extrait les valeurs tirées dans les distributions a posteriori des paramètres
post <- as_draws_df(lm.brms)

# crée une grille de x pour tracer l'intervalle de crédibilité
grille_x <- tibble(x = seq(min(data$x), max(data$x), length.out = 100))

# pour chaque x, simule des valeurs de y à partir des échantillons
pred <- post %>%
  select(b_Intercept, b_x) %>%
  expand_grid(grille_x) %>%
  mutate(y = b_Intercept + b_x * x) %>%
  group_by(x) %>%
  summarise(
    mean = mean(y),
    lower = quantile(y, 0.025),
    upper = quantile(y, 0.975),
    .groups = "drop"
  )

# extrait les moyennes a posteriori des paramètres
intercept <- summary(lm.brms)$fixed[1,1]
slope <- summary(lm.brms)$fixed[2,1]

# tracé
ggplot(data, aes(x = x, y = y)) +
  geom_point(alpha = 0.6) +
  geom_ribbon(data = pred, aes(x = x, ymin = lower, ymax = upper), fill = "blue", alpha = 0.2, inherit.aes = FALSE) +
  geom_line(data = pred, aes(x = x, y = mean), color = "blue", size = 1.2) +
  labs(x = "x", y = "y") +
  coord_cartesian(xlim = range(grille_x$x)) +
  theme_minimal()


## Posterior predictive checks réalisés avec brms. La courbe noire correspond 
## aux données observées, les courbes bleues aux données simulées selon le 
## modèle. L’axe des abscisses représente les valeurs possibles de la variable 
## réponse simulée ou observée. L’axe des ordonnées indique leur densité estimée.

pp_check(lm.brms)

# Extraire les simulations de y_rep
y_rep <- posterior_predict(lm.brms)

# Calculer la statistique de test sur les données simulées (moyenne ici)
T_sim <- rowMeans(y_rep)

# Calculer la statistique observée
T_obs <- mean(lm.brms$data$y)

# Calculer la Bayesian p-value
bayes_pval <- mean(T_sim >= T_obs)

# Afficher le résultat
bayes_pval

#' ## La comparaison de modèles

beta0 <- 0.1 # valeur vraie de l'intercept
beta1 <- 1 # valeur vraie du coefficient de x
sigma <- 0.5 # écart-type des erreurs
set.seed(666) # pour rendre la simulation reproductible
n <- 100 # nombre d'observations
x <- rnorm(n = n, mean = 0, sd = 1) # covariable x simulée selon une loi normale standard
epsilon <- rnorm(n, mean = 0, sd = sigma) # génère les erreurs normales
y <- beta0 + beta1 * x + epsilon # ajoute les erreurs à la relation linéaire
data <- data.frame(y = y, x = x)

# Modèle avec covariable
fit1 <- brm(y ~ x, data = data, family = gaussian(),
            prior = c(
              prior(normal(0, 1.5), class = Intercept),
              prior(normal(0, 1.5), class = b),
              prior(exponential(1), class = sigma)
            ),
            seed = 123, refresh = 0)

# Modèle sans covariable
fit0 <- brm(y ~ 1, data = data, family = gaussian(),
            prior = c(
              prior(normal(0, 1.5), class = Intercept),
              prior(exponential(1), class = sigma)
            ),
            seed = 123, refresh = 0)

# Calcul du WAIC pour chaque modèle
waic1 <- waic(fit1)
waic0 <- waic(fit0)

# Comparaison
waic1$estimates['waic',]
waic0$estimates['waic',]

# Leave-one-out cross-validation
loo1 <- loo(fit1)
loo0 <- loo(fit0)

# Comparaison
loo_compare(loo0, loo1)

#' ## En résumé
