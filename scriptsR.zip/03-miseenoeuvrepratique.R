#' # Mise en oeuvre pratique

#' ## Introduction

library(tidyverse)

#' ## La syntaxe du package `brms`

dat <- data.frame(y = 19, n = 57)

library(brms)

bayes.brms <- brm(y | trials(n) ~ 1,
                  family = binomial("logit"),
                  data = dat,
                  chains = 3,
                  iter = 2000,
                  warmup = 300,
                  thin = 1,
                  refresh = 0)

summary(bayes.brms)

library(posterior)
draws_fit <- as_draws_matrix(bayes.brms)

beta <- draws_fit[,'Intercept'] # sélectionne la colonne intercept
theta <- plogis(beta)  # conversion logit -> [0,1]

mean(theta)
quantile(theta, probas = c(2.5,97.5)/100)

summarise_draws(theta)

#' ## Visualisation

## Histogramme de la distribution a posteriori de la probabilité de survie theta.
draws_fit %>%
  ggplot(aes(x = theta)) +
  geom_histogram(color = "white", fill = "steelblue", bins = 30) +
  labs(x = "Probabilité de survie", y = "Fréquence")

## Histogramme de la distribution a posteriori et trace plot de la 
## probabilité de survie sur l’échelle logit (b). Dans l’histogramme, l’axe 
## des abscisses représente les valeurs possibles de l’intercept (échelle 
## logit) et l’axe des ordonnées la fréquence des valeurs simulées. Dans 
## le trace plot, l’axe des abscisses correspond au numéro de l’itération 
## MCMC et l’axe des ordonnées aux valeurs simulées de l’intercept (échelle 
## logit).

plot(bayes.brms)

beta <- draws_fit[,'Intercept'] # sélectionne la colonne intercept
theta <- plogis(beta)  # conversion logit -> [0,1]
lambda <- -1 / log(theta) # transforme survie en espérance de vie
summarize_draws(lambda) # résumé des tirages : moyenne, médiane, intervalles

## Histogramme de la distribution a posteriori de l'espérance de vie. 
## L'axe des abscisses représente les différentes valeurs possibles de 
## l'espérance de vie. L'axe vertical indique le nombre de tirages simulés 
## (Count) pour chaque valeur.
lambda %>%
  as_tibble() %>%
  ggplot() +
  geom_histogram(aes(x = Intercept), color = "white") +
  labs(x = "Espérance de vie")

#' ## Les priors

prior_summary(bayes.brms)

nlprior <- prior(normal(0, 1.5), class = "Intercept")

bayes.brms <- brm(y | trials(n) ~ 1,
                  family = binomial("logit"),
                  data = dat,
                  prior = nlprior, 
                  chains = 3,
                  iter = 2000,
                  warmup = 300,
                  thin = 1,
                  refresh = 0)

summary(bayes.brms)

#' ## En résumé
